#!/bin/bash
# Installs snapflip as a systemd service for the current user.
# Run as your normal user (not root) from the folder containing snapflip.py:
#   bash install.sh
set -euo pipefail

if [ "$EUID" -eq 0 ]; then
    echo "Run as your normal user (it will ask for sudo when needed)."
    exit 1
fi

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/snapflip"
VENV="$INSTALL_DIR/venv"

echo "Installing snapflip to $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
if [ "$SRC_DIR" != "$INSTALL_DIR" ]; then
    cp "$SRC_DIR/snapflip.py" "$INSTALL_DIR/snapflip.py"
fi

if ! python3 -m venv --help >/dev/null 2>&1; then
    sudo apt-get update && sudo apt-get install -y python3-venv
fi
python3 -m venv "$VENV"
"$VENV/bin/pip" install --quiet --upgrade pip
"$VENV/bin/pip" install --quiet pillow

sudo tee /etc/systemd/system/snapflip.service >/dev/null <<EOL
[Unit]
Description=snapflip - flipped camera snapshots for notifications
After=network.target crowsnest.service

[Service]
Type=simple
User=$USER
Environment=SNAPFLIP_UPSTREAM=http://127.0.0.1:8080/?action=snapshot
Environment=SNAPFLIP_FLIP=vertical
Environment=SNAPFLIP_PORT=8090
ExecStart=$VENV/bin/python3 $INSTALL_DIR/snapflip.py
Restart=always
RestartSec=2

[Install]
WantedBy=multi-user.target
EOL

# Let Moonraker/Fluidd show and restart it under service controls
ASVC="$HOME/printer_data/moonraker.asvc"
if [ -f "$ASVC" ] && ! grep -q "^snapflip$" "$ASVC"; then
    echo "snapflip" >> "$ASVC"
fi

sudo systemctl daemon-reload
sudo systemctl enable --now snapflip.service
sleep 2
if curl -s -o /dev/null -w "%{http_code} %{content_type}\n" http://127.0.0.1:8090/snapshot | grep -q "200 image/jpeg"; then
    echo "snapflip is running: http://127.0.0.1:8090/snapshot"
else
    echo "snapflip did not answer; check: journalctl -u snapflip -n 30"
    exit 1
fi
