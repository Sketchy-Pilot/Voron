#!/usr/bin/env python3
"""snapflip - serve a flipped snapshot of a ustreamer camera for notifications.

GET http://127.0.0.1:8090/snapshot  -> JPEG of the upstream snapshot, flipped.

If the camera can't be reached, a small "camera unavailable" JPEG is returned
instead of an error, so Moonraker/Apprise notifications still go out.

Settings (environment variables, set in the systemd unit):
  SNAPFLIP_UPSTREAM  default http://127.0.0.1:8080/?action=snapshot
  SNAPFLIP_FLIP      vertical | horizontal | rotate180 | none   (default vertical)
  SNAPFLIP_PORT      default 8090
  SNAPFLIP_BIND      default 127.0.0.1 (local only)
  SNAPFLIP_QUALITY   JPEG quality, default 85
"""
import io
import logging
import os
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from PIL import Image, ImageDraw

UPSTREAM = os.environ.get("SNAPFLIP_UPSTREAM", "http://127.0.0.1:8080/?action=snapshot")
FLIP = os.environ.get("SNAPFLIP_FLIP", "vertical").strip().lower()
PORT = int(os.environ.get("SNAPFLIP_PORT", "8090"))
BIND = os.environ.get("SNAPFLIP_BIND", "127.0.0.1")
QUALITY = int(os.environ.get("SNAPFLIP_QUALITY", "85"))
TIMEOUT = 5.0

T = getattr(Image, "Transpose", Image)  # Pillow >= 9.1 uses Image.Transpose
OPS = {
    "vertical": [T.FLIP_TOP_BOTTOM],
    "horizontal": [T.FLIP_LEFT_RIGHT],
    "rotate180": [T.ROTATE_180],
    "none": [],
}
if FLIP not in OPS:
    raise SystemExit("SNAPFLIP_FLIP must be one of: %s" % ", ".join(OPS))

log = logging.getLogger("snapflip")


def to_jpeg(img):
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="JPEG", quality=QUALITY)
    return buf.getvalue()


def unavailable_jpeg(reason):
    img = Image.new("RGB", (640, 360), (40, 40, 40))
    d = ImageDraw.Draw(img)
    d.text((20, 160), "Camera unavailable", fill=(230, 230, 230))
    d.text((20, 185), reason[:90], fill=(170, 170, 170))
    return to_jpeg(img)


def flipped_snapshot():
    with urllib.request.urlopen(UPSTREAM, timeout=TIMEOUT) as r:
        data = r.read()
    img = Image.open(io.BytesIO(data))
    for op in OPS[FLIP]:
        img = img.transpose(op)
    return to_jpeg(img)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = self.path.split("?", 1)[0].rstrip("/")
        if path not in ("/snapshot", ""):
            self.send_error(404)
            return
        try:
            body = flipped_snapshot()
        except Exception as e:  # camera unplugged, crowsnest down, bad frame...
            log.warning("upstream snapshot failed: %s", e)
            body = unavailable_jpeg(str(e))
        self.send_response(200)
        self.send_header("Content-Type", "image/jpeg")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        log.debug(fmt, *args)


def main():
    logging.basicConfig(level=logging.INFO, format="snapflip: %(message)s")
    log.info("serving %s flipped (%s) on http://%s:%d/snapshot", UPSTREAM, FLIP, BIND, PORT)
    ThreadingHTTPServer((BIND, PORT), Handler).serve_forever()


if __name__ == "__main__":
    main()
